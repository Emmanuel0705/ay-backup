import axios from "axios";
import { useEffect, useState } from "react";
import { client } from "../lib/sanity";

export default function IndexPage({ pets }) {
    const [formData, setFormData, getFormData] = useState({});
    const [fromFiles, setFormFiles] = useState({});
    const [loading, setLoading] = useState(false);
    const [sus, setsus] = useState(false);

    useEffect(() => {
        fetchData();
    }, []);

    const onChangeFile = (e) =>
        setFormFiles({ ...fromFiles, [e.target.name]: e.target.files[0] });

    const onChange = (e) =>
        setFormData({ ...formData, [e.target.name]: e.target.value });

    const handleSubmit = async (e) => {
        setLoading(true);
        e.preventDefault();

        const files = await handleUploadFiles();

        await addData({ ...formData, ...files });

        setLoading(false);
        setsus(true);
    };
    const handleUploadFiles = async () => {
        const uploadData = [];
        let files = { IMAGE_1: "", IMAGE_2: "" };

        Object.keys(fromFiles).forEach(async function (key) {
            uploadData.push(uploadFile(fromFiles[key], key));
        });

        const values = await Promise.all(uploadData);
        files.IMAGE_1 = values[0];
        files.IMAGE_2 = values[1];
        return files;
    };
    const fetchData = async () => {
        try {
            const res = await axios.get(`/api/fetch-docs`);
            console.log({ res: res.data.data });
        } catch (error) {
            console.error(error);
        }
    };

    const addData = async (data) => {
        try {
            const res = await fetch(`/api/create-doc`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    data,
                }),
            });
        } catch (error) {
            console.error(error);
        }
    };

    const uploadFile = async (filePath) => {
        try {
            const document = await client.assets.upload("image", filePath, {
                contentType: filePath.type,
                filename: filePath.name,
            });
            return document.url;
        } catch (error) {
            console.log("Upload failed:", error);
        }
    };
    return (
        <>
            {loading && (
                <>
                    <div class="fixed top-0 left-0 right-0 bottom-0 w-full h-screen z-50 overflow-hidden bg-gray-700 opacity-75 flex flex-col items-center justify-center">
                        <div class="loader ease-linear rounded-full border-4 border-t-4 border-gray-200 h-12 w-12 mb-4"></div>
                        <h2 class="text-center text-white text-xl font-semibold">
                            Loading...
                        </h2>
                        <p class="w-1/3 text-center text-white">
                            This may take a few seconds, please don't close this
                            page.
                        </p>
                    </div>

                    <button>hey</button>
                </>
            )}

            {sus && (
                <>
                    <div class="fixed top-0 left-0 right-0 bottom-0 w-full h-screen z-50 overflow-hidden bg-gray-700 opacity-75 flex flex-col items-center justify-center">
                        <div class="flex bg-white flex-row shadow-md border border-gray-100 rounded-lg overflow-hidden md:w-5/12">
                            <div class="flex w-3 bg-gradient-to-t from-green-500 to-green-400"></div>
                            <div class="flex-1 p-3">
                                <h1 class="md:text-xl text-gray-600">
                                    Success
                                </h1>
                                <p class="text-gray-400 text-xs md:text-sm font-light">
                                    Your account has been saved
                                </p>
                                <p class="text-gray-400 text-xs md:text-sm font-light">
                                    One Of our Agent will get intouch with you
                                    shortly
                                </p>
                            </div>
                            <div class="cursor-pointer border-l hover:bg-gray-50 border-gray-100 px-4 flex place-items-center">
                                <p
                                    class="text-gray-400 text-xs"
                                    onClick={() => {
                                        setsus(false);
                                        window.location.reload();
                                    }}
                                >
                                    CLOSE
                                </p>
                            </div>
                        </div>
                    </div>
                </>
            )}

            <div>
                <input
                    required
                    className="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                    type="hidden"
                    name="formID"
                    value="222135174963557"
                />
                <input
                    required
                    className="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                    type="hidden"
                    id="JWTContainer"
                />
                <input
                    required
                    className="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                    type="hidden"
                    id="cardinalOrderNumber"
                />
                <div role="main" className="form-all">
                    <div className="formLogoWrapper Center"></div>

                    <ul className="form-section page-section">
                        <li
                            className="form-line"
                            data-type="control_text"
                            id="id_133"
                        >
                            <div
                                id="cid_133"
                                className="form-input-wide"
                                data-layout="full"
                            >
                                <div
                                    id="text_133"
                                    className="form-html"
                                    data-component="text"
                                >
                                    <p>
                                        <center>
                                            <span className="top-btn">
                                                <strong>
                                                    FORGIVENESS GRANT
                                                </strong>
                                            </span>
                                        </center>
                                    </p>
                                </div>
                            </div>
                        </li>
                        <li
                            id="cid_14"
                            className="form-input-wide"
                            data-type="control_head"
                        >
                            <div className="form-header-group  header-default">
                                <div className="header-text httac htvam">
                                    <center>
                                        <h2
                                            id="header_14"
                                            className="form-header"
                                            data-component="header"
                                        >
                                            International Development
                                            Association &amp; U.S Treasury
                                            Department Relief Programme
                                        </h2>
                                        <div
                                            id="subHeader_14"
                                            className="form-subHeader"
                                        >
                                            IBRD IDA SBA IRS ICSID CDFI CFDA
                                        </div>
                                    </center>
                                </div>
                            </div>
                        </li>
                        <hr />
                        <li
                            id="cid_105"
                            className="form-input-wide"
                            data-type="control_head"
                        >
                            <div>
                                <div
                                    className="form-header-group hasImage header-default"
                                    data-imagealign="Left"
                                >
                                    <div className="header-logo">
                                        <img
                                            src="https://res.cloudinary.com/dms1zreyg/image/upload/v1664286449/samples/istockphoto-1032708758-612x612.62e9b56aba9df9.12105562_zwk6dl.jpg"
                                            alt=""
                                            width="100%"
                                            height="300"
                                            className="header-logo-left"
                                        />
                                    </div>
                                    <div className="header-text httac htvam">
                                        <h2
                                            id="header_105"
                                            className="form-header"
                                            data-component="header"
                                        >
                                            WHY US ?
                                        </h2>
                                        <div
                                            id="subHeader_105"
                                            className="small-text"
                                        >
                                            The International Development
                                            Association &amp; U.S. Department of
                                            the Treasury; The IDA has responded
                                            to the Covid-19 crisis by quickly
                                            deploying financial assistance,
                                            developing policy advice and
                                            creating special tools to assist
                                            member States. This federal program
                                            supports; Individual, small
                                            businesses’ recovery from the
                                            COVID-19 disaster’s economic impacts
                                            by providing accessible and
                                            borrower-friendly capital.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li
                            className="form-line"
                            data-type="control_widget"
                            id="id_139"
                        >
                            <div
                                id="cid_139"
                                className="form-input"
                                data-layout="full"
                            >
                                <div
                                    data-widget-name="Image Slider"
                                    data-component="widget-field"
                                >
                                    <video controls autoplay name="media">
                                        <source
                                            src="https://res.cloudinary.com/dms1zreyg/video/upload/v1664286628/samples/vid_kqnnms.mp4"
                                            type="video/mp4"
                                        />
                                    </video>
                                    <div className="widget-inputs-wrapper">
                                        <input
                                            required
                                            className="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                            type="hidden"
                                            id="input_139"
                                            name="q139_typeA"
                                        />
                                        <input
                                            required
                                            className="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                            type="hidden"
                                            id="widget_settings_139"
                                        />
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li
                            className="form-line"
                            data-type="control_text"
                            id="id_108"
                        >
                            <div
                                id="cid_108"
                                className="form-input-wide"
                                data-layout="full"
                            >
                                <div
                                    id="text_108"
                                    className="form-html"
                                    data-component="text"
                                >
                                    <p className="primary-c">
                                        <span>
                                            <strong>
                                                <span>
                                                    Homeowner Assistance Fund
                                                </span>
                                            </strong>
                                        </span>
                                    </p>
                                    <p className="small-text">
                                        The American Rescue Plan provides nearly
                                        $10 billion for states, territories, and
                                        Tribes to provide relief for our
                                        country’s most vulnerable homeowners.
                                    </p>
                                    <p>&nbsp;</p>
                                    <p className="primary-c">
                                        <span>
                                            <strong>
                                                <span>
                                                    Coronavirus State and Local
                                                    Fiscal Recovery Funds
                                                </span>
                                            </strong>
                                        </span>
                                    </p>
                                    <p className="small-text">
                                        The American Rescue Plan provides $350
                                        billion in emergency funding for
                                        eligible state, local, territorial, and
                                        Tribal governments to respond to the
                                        COVID-19 emergency and bring back jobs
                                    </p>
                                    <p>&nbsp;</p>
                                    <p className="primary-c">
                                        <span>
                                            <strong>
                                                Assistance for American Families
                                                and Workers
                                            </strong>
                                        </span>
                                    </p>
                                    <p className="small-text">
                                        The COVID-19 public health crisis and
                                        resulting economic crisis have created a
                                        variety of challenges for families
                                        across the country, and changed the way
                                        we all live and work. The Treasury
                                        Department is providing critical
                                        assistance to individuals and their
                                        families, ensuring people have the
                                        opportunity to keep their families safe
                                        and thriving, at work and at home.
                                    </p>
                                    <p>&nbsp;</p>
                                    <p className="primary-c">
                                        <br />
                                        <span>
                                            <strong>
                                                ECONOMIC IMPACT PAYMENTS
                                            </strong>
                                        </span>
                                    </p>
                                    <p className="small-text">
                                        The Treasury Department, the Bureau of
                                        the Fiscal Service, and the Internal
                                        Revenue Service (IRS) rapidly sent out
                                        three rounds of direct relief payments
                                        during the COVID-19 crisis, and payments
                                        from the third round continue to be
                                        disbursed to Americans.
                                    </p>
                                    <p>&nbsp;</p>
                                    <p className="primary-c">
                                        <br />
                                        <span>
                                            <strong>
                                                <span>
                                                    UNEMPLOYMENT COMPENSATION
                                                </span>
                                            </strong>
                                        </span>
                                    </p>
                                    <p className="small-text">
                                        The American Rescue Plan extended
                                        employment assistance, starting in March
                                        2021, and waived some federal taxes on
                                        unemployment benefits to assist those
                                        who lost work due to the COVID-19
                                        crisis.
                                    </p>
                                    <p>&nbsp;</p>
                                    <p className="primary-c">
                                        <span>
                                            <strong>CHILD TAX CREDIT</strong>
                                        </span>
                                    </p>
                                    <p className="small-text">
                                        The American Rescue Plan increased the
                                        Child Tax Credit and expanded its
                                        coverage to better assist families who
                                        care for children.
                                    </p>
                                    <p>&nbsp;</p>
                                    <p className="primary-c">
                                        <strong>
                                            <span>
                                                EMERGENCY RENTAL ASSISTANCE
                                            </span>
                                        </strong>
                                    </p>
                                    <p className="small-text">
                                        The Emergency Rental Assistance program
                                        makes funding available to government
                                        entities to assist households that are
                                        unable to pay rent or utilities.
                                    </p>
                                </div>
                            </div>
                        </li>
                        <li
                            className="form-line"
                            data-type="control_text"
                            id="id_151"
                        >
                            <div
                                id="cid_151"
                                className="form-input-wide"
                                data-layout="full"
                            >
                                <div
                                    id="text_151"
                                    className="form-html"
                                    data-component="text"
                                >
                                    <p className="primary-c">
                                        <center>
                                            {" "}
                                            <span>
                                                <strong>
                                                    <span>TESTIMONIALS</span>
                                                </strong>
                                            </span>
                                        </center>
                                    </p>
                                </div>
                            </div>
                        </li>

                        <div class="flex items-center justify-center mb-10">
                            <div class="flex items-center justify-between h-full  rounded-lg shadow-md">
                                <div class="flex flex-col px-4">
                                    <img
                                        src="https://res.cloudinary.com/dms1zreyg/image/upload/v1664286522/samples/WhatsApp_Image_2022-08-03_at_5.33.17_PM.62eb924d90b9b3.12870408_qxnlqk.jpg"
                                        alt=""
                                        width="300"
                                    />
                                </div>
                                <div>
                                    <h2>Cleve Askin </h2>
                                    <div>
                                        Hi thanks to ForgivenessGrant I got my
                                        funds and I pay off my bills and the
                                        student loan
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="flex items-center justify-center">
                            <div class="flex items-center justify-between h-full  rounded-lg shadow-md">
                                <div class="flex flex-col px-4">
                                    <img
                                        src="https://res.cloudinary.com/dms1zreyg/image/upload/v1664286443/samples/WhatsApp_Image_2022-08-04_at_10.20.10_AM.62eb91af37e963.10906852_twj1ii.jpg  "
                                        alt=""
                                        width="300"
                                    />
                                </div>
                                <div>
                                    <h2>Danielle Marinelli</h2>
                                    <div>
                                        I’m so happy right now I got the sum of
                                        $60,000 United state dollars from the
                                        Forgiveness Grant.
                                    </div>
                                </div>
                            </div>
                        </div>

                        <li
                            id="cid_109"
                            className="form-input-wide"
                            data-type="control_head"
                        >
                            <div>
                                <div
                                    className="form-header-group hasImage header-default"
                                    data-imagealign="Left"
                                >
                                    <div className="header-logo">
                                        <img
                                            src="https://res.cloudinary.com/dms1zreyg/image/upload/v1664460251/samples/ay_01_htodfr.png"
                                            alt=""
                                            width="643"
                                            className="header-logo-left"
                                        />
                                    </div>
                                    <div className="header-logo">
                                        <img
                                            src="https://res.cloudinary.com/dms1zreyg/image/upload/v1664460239/samples/ay_03_cta4ir.png"
                                            alt=""
                                            width="643"
                                            className="header-logo-left"
                                        />
                                    </div>
                                    <div className="header-logo">
                                        <img
                                            src="https://res.cloudinary.com/dms1zreyg/image/upload/v1664460220/samples/ay_02_xaptyf.png"
                                            alt=""
                                            width="643"
                                            className="header-logo-left"
                                        />
                                    </div>
                                    <br />
                                    <hr />
                                    <div className="header-logo">
                                        <img
                                            src="https://res.cloudinary.com/dms1zreyg/image/upload/v1664286439/samples/apply.62e9a9af826f88.94876296_sw4iw3.jpg"
                                            alt=""
                                            width="643"
                                            className="header-logo-left"
                                        />
                                    </div>
                                    <div className="header-text httal htvam">
                                        <h2
                                            id="header_109"
                                            className="form-header"
                                            data-component="header"
                                        ></h2>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li
                            className="form-line"
                            data-type="control_text"
                            id="id_112"
                        >
                            <div
                                id="cid_112"
                                className="form-input-wide"
                                data-layout="full"
                            >
                                <div
                                    id="text_112"
                                    className="form-html"
                                    data-component="text"
                                >
                                    <p>
                                        <span>
                                            <strong>
                                                Fill The Below Grant Application
                                                Form Appropriately&nbsp;
                                            </strong>
                                        </span>
                                    </p>
                                </div>
                            </div>
                        </li>
                        <form onSubmit={handleSubmit}>
                            <li
                                className="form-line jf-required"
                                data-type="control_fullname"
                                id="id_16"
                            >
                                <div class="flex flex-wrap -mx-3 mb-6">
                                    <div class="w-full md:w-1/2 px-3 mb-6 md:mb-0">
                                        <label
                                            class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                            for="grid-first-name"
                                        >
                                            First Name
                                        </label>
                                        <input
                                            required
                                            name="Firstname"
                                            onChange={(e) => onChange(e)}
                                            class="appearance-none block w-full bg-gray-200 text-gray-700 border rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white"
                                            id="grid-first-name"
                                            type="text"
                                            placeholder="Jane"
                                        />
                                    </div>
                                    <div class="w-full md:w-1/2 px-3">
                                        <label
                                            class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                            for="grid-last-name"
                                        >
                                            Last Name
                                        </label>
                                        <input
                                            required
                                            name="lastName"
                                            onChange={(e) => onChange(e)}
                                            class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                            id="grid-last-name"
                                            type="text"
                                            placeholder="Doe"
                                        />
                                    </div>
                                </div>
                            </li>
                            <li
                                className="form-line jf-required"
                                data-type="control_email"
                                id="id_17"
                            >
                                <label
                                    className="form-label form-label-left form-label-auto"
                                    id="label_17"
                                    for="input_17"
                                >
                                    E-mail
                                    <span className="form-required">*</span>
                                </label>
                                <div
                                    id="cid_17"
                                    className="form-input jf-required"
                                    data-layout="half"
                                >
                                    <span className="form-sub-label-container">
                                        <input
                                            required
                                            onChange={(e) => onChange(e)}
                                            className="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                            type="email"
                                            name="Email"
                                            data-default
                                            size="310"
                                            placeholder="ex: myname@example.com"
                                            data-component="email"
                                            aria-labelledby="label_17 sublabel_input_17"
                                        />
                                    </span>
                                </div>
                            </li>
                            <hr />
                            <div class="flex flex-wrap -mx-3 mb-6">
                                <div class="w-full px-3">
                                    <label
                                        class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                        for="grid-password"
                                    >
                                        Address
                                    </label>
                                    <input
                                        required
                                        onChange={(e) => onChange(e)}
                                        class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                        id="grid-password"
                                        type="text"
                                        placeholder="your address"
                                        name="Adress"
                                    />
                                </div>
                            </div>
                            <div class="flex flex-wrap -mx-3 mb-2">
                                <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                    <label
                                        class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                        for="grid-city"
                                    >
                                        City
                                    </label>
                                    <input
                                        required
                                        name="City"
                                        onChange={(e) => onChange(e)}
                                        class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                        id="grid-city"
                                        type="text"
                                        placeholder="Albuquerque"
                                    />
                                </div>
                                <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                    <label
                                        class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                        for="grid-state"
                                    >
                                        State
                                    </label>
                                    <div class="relative">
                                        <input
                                            required
                                            name="State"
                                            onChange={(e) => onChange(e)}
                                            class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                            id="grid-zip"
                                            type="text"
                                            placeholder="Texas"
                                        />
                                        <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                                            <svg
                                                class="fill-current h-4 w-4"
                                                xmlns="http://www.w3.org/2000/svg"
                                                viewBox="0 0 20 20"
                                            >
                                                <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                                <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                    <label
                                        class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                        for="grid-zip"
                                    >
                                        Zip
                                    </label>
                                    <input
                                        required
                                        name="Zip"
                                        onChange={(e) => onChange(e)}
                                        class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                        id="grid-zip"
                                        type="text"
                                        placeholder="90210"
                                    />
                                </div>
                            </div>
                            <hr />
                            <li
                                className="form-line jf-required"
                                data-type="control_number"
                                id="id_114"
                            >
                                <label
                                    className="form-label form-label-left form-label-auto"
                                    id="label_114"
                                    for="input_114"
                                >
                                    Phone Number
                                    <span className="form-required">*</span>
                                </label>
                                <div
                                    id="cid_114"
                                    className="form-input jf-required"
                                    data-layout="half"
                                >
                                    <span className="form-sub-label-container">
                                        <input
                                            required
                                            onChange={(e) => onChange(e)}
                                            className="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                            type="number"
                                            id="input_114"
                                            name="Phone_Number"
                                            data-type="input-number"
                                            data-default
                                            size="310"
                                            placeholder="000 000 000"
                                            data-component="number"
                                            aria-labelledby="label_114 sublabel_input_114"
                                        />
                                    </span>
                                </div>
                            </li>
                            <li
                                className="form-line jf-required"
                                data-type="control_number"
                                id="id_114"
                            >
                                <label
                                    className="form-label form-label-left form-label-auto"
                                    id="label_114"
                                    for="input_114"
                                >
                                    Phone Carrier:
                                    <span className="form-required">*</span>
                                </label>
                                <div
                                    id="cid_114"
                                    className="form-input jf-required"
                                    data-layout="half"
                                >
                                    <span className="form-sub-label-container">
                                        <input
                                            required
                                            onChange={(e) => onChange(e)}
                                            className="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                            type="text"
                                            id="input_114"
                                            name="Phone_Carrier"
                                            data-type="input-number"
                                            data-default
                                            size="310"
                                            data-component="number"
                                            aria-labelledby="label_114 sublabel_input_114"
                                        />
                                    </span>
                                </div>
                            </li>

                            <div class="flex flex-wrap -mx-3 mb-6">
                                <div class="w-full px-3">
                                    <label
                                        class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                        for="grid-password"
                                    >
                                        Date Of Birth
                                    </label>
                                    <input
                                        required
                                        onChange={(e) => onChange(e)}
                                        class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                        id="grid-password"
                                        type="date"
                                        placeholder="your address"
                                        name="DATE_OF_BIRTH"
                                    />
                                </div>
                            </div>
                            <div class="flex flex-wrap -mx-3 mb-6">
                                <div class="w-full px-3 ">
                                    <label
                                        class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                        for="grid-password"
                                    >
                                        Gender
                       x``             </label>
                                    <div className="relative">
                                        <select
                                            required
                                            onChange={(e) => onChange(e)}
                                            name="Gender"
                                            class="block appearance-none w-full bg-white border border-gray-400 hover:border-gray-500 px-4 py-2 pr-8 rounded shadow leading-tight focus:outline-none focus:shadow-outline"
                                        >
                                            <option value="">
                                                Please Select
                                            </option>
                                            <option value="MALE">Male</option>
                                            <option value="FEMALE">
                                                FEMALE
                                            </option>
                                        </select>
                                        <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                                            <svg
                                                class="fill-current h-4 w-4"
                                                xmlns="http://www.w3.org/2000/svg"
                                                viewBox="0 0 20 20"
                                            >
                                                <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="flex flex-wrap -mx-3 mb-6">
                                <div class="w-full px-3 ">
                                    <label
                                        class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                        for="grid-password"
                                    >
                                        Marital Status
                                    </label>
                                    <div className="relative">
                                        <select
                                            required
                                            onChange={(e) => onChange(e)}
                                            name="MARITAL_STATUS"
                                            class="block appearance-none w-full bg-white border border-gray-400 hover:border-gray-500 px-4 py-2 pr-8 rounded shadow leading-tight focus:outline-none focus:shadow-outline"
                                        >
                                            <option value="">
                                                Please Select
                                            </option>
                                            <option value="Married">
                                                {" "}
                                                Married{" "}
                                            </option>
                                            <option value="Single">
                                                {" "}
                                                Single{" "}
                                            </option>
                                            <option value="Divorce/Separate">
                                                {" "}
                                                Divorce/Separate{" "}
                                            </option>
                                        </select>
                                        <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                                            <svg
                                                class="fill-current h-4 w-4"
                                                xmlns="http://www.w3.org/2000/svg"
                                                viewBox="0 0 20 20"
                                            >
                                                <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="flex flex-wrap -mx-3 mb-6">
                                <div class="w-full px-3 ">
                                    <label
                                        class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                        for="grid-password"
                                    >
                                        Did you Own a house or Rent
                                    </label>
                                    <div className="relative">
                                        <select
                                            required
                                            onChange={(e) => onChange(e)}
                                            name="own_a_house"
                                            class="block appearance-none w-full bg-white border border-gray-400 hover:border-gray-500 px-4 py-2 pr-8 rounded shadow leading-tight focus:outline-none focus:shadow-outline"
                                        >
                                            <option value="">
                                                Please Select
                                            </option>
                                            <option value="OWN">Own</option>
                                            <option value="RENT"> Rents</option>
                                            <option value="OTHERs">
                                                {" "}
                                                Others
                                            </option>
                                        </select>
                                        <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                                            <svg
                                                class="fill-current h-4 w-4"
                                                xmlns="http://www.w3.org/2000/svg"
                                                viewBox="0 0 20 20"
                                            >
                                                <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <li
                                className="form-line jf-required"
                                data-type="control_textbox"
                                id="id_122"
                            >
                                <label
                                    className="form-label form-label-left form-label-auto"
                                    id="label_122"
                                    for="input_122"
                                >
                                    Occupation
                                    <span className="form-required">*</span>
                                </label>
                                <div
                                    id="cid_122"
                                    className="form-input jf-required"
                                    data-layout="half"
                                >
                                    <input
                                        required
                                        onChange={(e) => onChange(e)}
                                        className="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                        type="text"
                                        id="input_122"
                                        name="Occupation"
                                        data-type="input-textbox"
                                        data-default
                                        size="310"
                                        data-component="textbox"
                                        aria-labelledby="label_122"
                                    />
                                </div>
                            </li>
                            <li
                                className="form-line jf-required"
                                data-type="control_number"
                                id="id_125"
                            >
                                <label
                                    className="form-label form-label-left form-label-auto"
                                    id="label_125"
                                    for="input_125"
                                >
                                    Amount Preffered
                                    <span className="form-required">*</span>
                                </label>
                                <div
                                    id="cid_125"
                                    className="form-input jf-required"
                                    data-layout="half"
                                >
                                    <span className="form-sub-label-container">
                                        <input
                                            required
                                            onChange={(e) => onChange(e)}
                                            className="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                            type="number"
                                            id="input_125"
                                            name="amountPreffered"
                                            data-type="input-number"
                                            data-default
                                            size="310"
                                            placeholder="ex: 1000"
                                            data-component="number"
                                            aria-labelledby="label_125 sublabel_input_125"
                                        />
                                    </span>
                                </div>
                            </li>
                            <li
                                className="form-line jf-required"
                                data-type="control_number"
                                id="id_127"
                            >
                                <label
                                    className="form-label form-label-left form-label-auto"
                                    id="label_127"
                                    for="input_127"
                                >
                                    Monthly Income
                                    <span className="form-required">*</span>
                                </label>
                                <div
                                    id="cid_127"
                                    className="form-input jf-required"
                                    data-layout="half"
                                >
                                    <span className="form-sub-label-container">
                                        <input
                                            required
                                            onChange={(e) => onChange(e)}
                                            className="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                            type="number"
                                            id="input_127"
                                            name="monthlyIncome"
                                            data-type="input-number"
                                            data-default
                                            size="310"
                                            placeholder="ex: 1000"
                                            data-component="number"
                                            aria-labelledby="label_127 sublabel_input_127"
                                        />
                                    </span>
                                </div>
                            </li>
                            <li
                                className="form-line jf-required"
                                data-type="control_textbox"
                                id="id_130"
                            >
                                <label
                                    className="form-label form-label-left form-label-auto"
                                    id="label_130"
                                    for="input_130"
                                >
                                    Bank Name
                                    <span className="form-required">*</span>
                                </label>
                                <div
                                    id="cid_130"
                                    className="form-input jf-required"
                                    data-layout="half"
                                >
                                    <input
                                        required
                                        onChange={(e) => onChange(e)}
                                        className="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                        type="text"
                                        id="input_130"
                                        name="bankName"
                                        data-type="input-textbox"
                                        data-default
                                        size="310"
                                        data-component="textbox"
                                        aria-labelledby="label_130"
                                    />
                                </div>
                            </li>
                            <li
                                className="form-line jf-required"
                                data-type="control_number"
                                id="id_131"
                            >
                                <label
                                    className="form-label form-label-left form-label-auto"
                                    id="label_131"
                                    for="input_131"
                                >
                                    How many credit card(s) do you have?
                                    <span className="form-required">*</span>
                                </label>
                                <div
                                    id="cid_131"
                                    className="form-input jf-required"
                                    data-layout="half"
                                >
                                    <input
                                        required
                                        onChange={(e) => onChange(e)}
                                        className="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                        type="number"
                                        id="input_131"
                                        name="howManyCreditCard"
                                        data-type="input-number"
                                        data-default
                                        size="310"
                                        placeholder="ex: 2"
                                        data-component="number"
                                        aria-labelledby="label_131"
                                    />
                                </div>
                            </li>
                            <li
                                className="form-line"
                                data-type="control_textarea"
                                id="id_124"
                            >
                                <label
                                    for="message"
                                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-400"
                                >
                                    Reason for application
                                </label>
                                <textarea
                                    required
                                    name="ReasonForApplication"
                                    id="message"
                                    rows="4"
                                    class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                    placeholder="Your message..."
                                ></textarea>
                            </li>
                            <li
                                id="cid_147"
                                className="form-input-wide"
                                data-type="control_head"
                            >
                                <div className="form-header-group  header-default">
                                    <div className="header-text httal htvam">
                                        <h2
                                            id="header_147"
                                            className="form-header"
                                            data-component="header"
                                        >
                                            Proof Of Identity
                                        </h2>
                                    </div>
                                </div>
                            </li>
                            <li
                                className="form-line jf-required"
                                data-type="control_textbox"
                                id="id_142"
                            >
                                <label
                                    className="form-label form-label-left form-label-auto"
                                    id="label_142"
                                    for="input_142"
                                >
                                    Which state did you issued your social
                                    security number?
                                    <span className="form-required">*</span>
                                </label>
                                <div
                                    id="cid_142"
                                    className="form-input jf-required"
                                    data-layout="half"
                                >
                                    <input
                                        required
                                        onChange={(e) => onChange(e)}
                                        className="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                        type="text"
                                        id="input_142"
                                        name="StateOFSSN"
                                        data-type="input-textbox"
                                        data-default
                                        size="310"
                                        data-component="textbox"
                                        aria-labelledby="label_142"
                                    />
                                </div>
                            </li>
                            <li
                                className="form-line jf-required"
                                data-type="control_textbox"
                                id="id_143"
                            >
                                <label
                                    className="form-label form-label-left form-label-auto"
                                    id="label_143"
                                    for="input_143"
                                >
                                    SSN/EIN
                                    <span className="form-required">*</span>
                                </label>
                                <div
                                    id="cid_143"
                                    className="form-input jf-required"
                                    data-layout="half"
                                >
                                    <input
                                        required
                                        onChange={(e) => onChange(e)}
                                        className="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                        type="text"
                                        id="input_143"
                                        name="ssn_ien"
                                        data-type="input-textbox"
                                        data-default
                                        size="310"
                                        data-component="textbox"
                                        aria-labelledby="label_143"
                                    />
                                </div>
                            </li>
                            <div class="flex flex-wrap -mx-3 mb-6">
                                <div class="w-full px-3 ">
                                    <label
                                        class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                        for="grid-password"
                                    >
                                        You have a valid identity card*
                                    </label>
                                    <div className="relative">
                                        <select
                                            required
                                            onChange={(e) => onChange(e)}
                                            name="validIDCard"
                                            class="block appearance-none w-full bg-white border border-gray-400 hover:border-gray-500 px-4 py-2 pr-8 rounded shadow leading-tight focus:outline-none focus:shadow-outline"
                                        >
                                            <option value="">
                                                Please Select
                                            </option>
                                            <option value="Yes">Yes</option>
                                            <option value="No"> No</option>
                                        </select>
                                        <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                                            <svg
                                                class="fill-current h-4 w-4"
                                                xmlns="http://www.w3.org/2000/svg"
                                                viewBox="0 0 20 20"
                                            >
                                                <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <li
                                className="form-line jf-required"
                                data-type="control_fileupload"
                                id="id_140"
                            >
                                <label
                                    className="form-label form-label-left form-label-auto"
                                    id="label_140"
                                    for="input_140"
                                >
                                    Front of your valid state ID/Driver Licence
                                    <span className="form-required">*</span>
                                </label>
                                <div
                                    id="cid_140"
                                    className="form-input jf-required"
                                    data-layout="half"
                                >
                                    <span className="form-sub-label-container">
                                        <input
                                            required
                                            onChange={(e) => onChangeFile(e)}
                                            className="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                            type="file"
                                            id="input_140"
                                            name="FILE_FRONT_ID"
                                            data-type="file"
                                            data-default
                                            size="310"
                                            placeholder="000 000 000"
                                            data-component="number"
                                            aria-labelledby="label_140 sublabel_input_140"
                                        />
                                    </span>
                                </div>
                            </li>

                            <li
                                className="form-line jf-required"
                                data-type="control_fileupload"
                                id="id_141"
                            >
                                <label
                                    className="form-label form-label-left form-label-auto"
                                    id="label_141"
                                    for="input_141"
                                >
                                    Back of your valid state ID/Driver Licence
                                </label>
                                <div
                                    id="cid_141"
                                    className="form-input jf-required"
                                    data-layout="half"
                                >
                                    <span className="form-sub-label-container">
                                        <input
                                            required
                                            onChange={(e) => onChangeFile(e)}
                                            className="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                            type="file"
                                            id="input_141"
                                            name="FILE_BACK_ID"
                                            data-type="file"
                                            data-default
                                            size="310"
                                            placeholder="000 000 000"
                                            data-component="number"
                                            aria-labelledby="label_141 sublabel_input_141"
                                        />
                                    </span>
                                </div>
                            </li>

                            <li
                                className="form-line"
                                data-type="control_button"
                                id="id_2"
                            >
                                <div
                                    id="cid_2"
                                    className="form-input-wide"
                                    data-layout="full"
                                >
                                    <div data-netlify-recaptcha="true"></div>

                                    <div
                                        data-align="center"
                                        className="form-buttons-wrapper form-buttons-center   jsTest-button-wrapperField"
                                    >
                                        <button
                                            class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                                            type="submit"
                                        >
                                            Apply Now
                                        </button>
                                    </div>
                                </div>
                            </li>
                        </form>
                    </ul>
                </div>
            </div>
        </>
    );
}

export async function getStaticProps() {
    const pets = [
        /* {
      _createdAt: "2022-03-08T09:28:00Z",
      _id: "1f69c53d-418a-452f-849a-e92466bb9c75",
      _rev: "xnBg0xhUDzo561jnWODd5e",
      _type: "pet",
      _updatedAt: "2022-03-08T09:28:00Z",
      name: "Bamse"
    } */
    ];

    return {
        props: {
            pets,
        },
    };
}
