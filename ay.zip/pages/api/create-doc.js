import { client } from "../../lib/sanity";

const createUserOnSanity = async (req, res) => {
    try {
        const userDoc = {
            _type: "users",
            _id: Date.now(),
            data: req.body.data,
        };

        // await client.delete('*[_type == "users"]');

        await client.create(userDoc);

        res.status(200).send({ message: "success" });
    } catch (error) {
        console.log({ error });
        res.status(500).send({ message: "error", data: error.message });
    }
};

export default createUserOnSanity;
