import axios from "axios";
import { useEffect, useState } from "react";

export default function IndexPage({ pets }) {
    const [docs, setDocs] = useState([]);

    useEffect(() => {
        console.log(docs);
        fetchData();
    }, []);

    const fetchData = async () => {
        try {
            const res = await axios.get(`/api/fetch-docs`);
            console.log({ res: res.data.data });
            setDocs(res.data.data);
        } catch (error) {
            console.error(error);
        }
    };

    return (
        <>
            <center>
                <h2 className="text-5xl py-6">ALL RESPONSE</h2>
            </center>
            {docs.map((e) => (
                <div className="px-5">
                    <div className="bg-white rounded-lg shadow">
                        <ul className="divide-y-2 divide-gray-100">
                            <li className="">
                                Name : {e.data.Firstname} {e.data.lastName}
                            </li>
                            <li className="">Email : {e.data.Email}</li>
                            <li className="">Gender : {e.data.Gender}</li>
                            <li className="">
                                Phone nUmber : {e.data.Phone_Number}
                            </li>
                            <li className="">
                                Phone Carrier : {e.data.Phone_Carrier}
                            </li>
                            <li className="">
                                Occupation : {e.data.Occupation}
                            </li>
                            <li className="">
                                MARITAL STATUS : {e.data.MARITAL_STATUS}
                            </li>
                            <li className="">
                                Date Of Birth : {e.data.DATE_OF_BIRTH}
                            </li>
                            <li className="">
                                Amount Preffered : {e.data.amountPreffered}
                            </li>
                            <li className="">
                                Montly Income: {e.data.monthlyIncome}
                            </li>
                            <li className="">STATE : {e.data.State}</li>
                            <li className="">Address : {e.data.Address}</li>
                            <li className="">City : {e.data.City}</li>
                            <li className="">Zip Code : {e.data.zip}</li>
                            <li className="">Zip Code : {e.data.zip}</li>
                            <li className="">BankName : {e.data.bankName}</li>
                            <li className="">
                                Own A House : {e.data.own_a_house}
                            </li>
                            <li className="">SSN?/IEN : {e.data.ssn_ien}</li>
                            <li className="">
                                SSN Registered State : {e.data.StateOFSSN}
                            </li>
                            <li className="">
                                How Many Credit Card :{" "}
                                {e.data.howManyCreditCard}
                            </li>
                            <li className="">
                                Has Vailid Id : {e.data.validIDCard}
                            </li>
                            <li className="">
                                <img width="200" src={`${e?.data?.IMAGE_1}`} />
                                <img width="200" src={`${e?.data?.IMAGE_2}`} />
                            </li>
                        </ul>
                    </div>
                </div>
            ))}
        </>
    );
}

export async function getStaticProps() {
    const pets = [
        /* {
      _createdAt: "2022-03-08T09:28:00Z",
      _id: "1f69c53d-418a-452f-849a-e92466bb9c75",npm 
      _rev: "xnBg0xhUDzo561jnWODd5e",
      _type: "pet",
      _updatedAt: "2022-03-08T09:28:00Z",
      name: "Bamse"
    } */
    ];

    return {
        props: {
            pets,
        },
    };
}
